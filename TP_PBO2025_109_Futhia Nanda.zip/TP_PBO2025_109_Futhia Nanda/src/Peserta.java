import java.util.ArrayList;

public class Peserta extends User {

    private ArrayList<KursusPeserta> daftarKursus = new ArrayList<>();

    public Peserta(String id, String nama) {
        super(id, nama);
    }

    public ArrayList<KursusPeserta> getDaftarKursus() {
        return daftarKursus;
    }

    public void tambahKursus(KursusPeserta kp) {
        daftarKursus.add(kp);
    }
}
