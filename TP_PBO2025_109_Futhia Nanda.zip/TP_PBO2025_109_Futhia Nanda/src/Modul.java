public class Modul {
    private String nama;
    private int bobot;

    public Modul(String nama, int bobot) {
        this.nama = nama;
        this.bobot = bobot;
    }

    public int getBobot() {
        return bobot;
    }

    public String getNama() {
        return nama;
    }
}
