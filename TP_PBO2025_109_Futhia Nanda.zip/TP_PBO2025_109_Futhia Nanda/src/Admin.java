import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;

public class Admin extends User {

    public Admin(String id, String nama) {
        super(id, nama);
    }

    public void tambahMentor(ArrayList<Mentor> daftarMentor, Mentor m) {
        daftarMentor.add(m);
        try (FileWriter fw = new FileWriter("mentor.txt", true)) {
            fw.write(m.getId() + "|" + m.getNama() + "\n");
        } catch (IOException e) {
            System.out.println("Gagal menyimpan mentor.");
        }
        System.out.println("Mentor berhasil ditambahkan.");
    }

    public void hapusMentor(ArrayList<Mentor> daftarMentor, int index) {
        if (index >= 0 && index < daftarMentor.size()) {
            daftarMentor.remove(index);
            try (FileWriter fw = new FileWriter("mentor.txt")) {
                for (Mentor m : daftarMentor) {
                    fw.write(m.getId() + "|" + m.getNama() + "\n");
                }
            } catch (IOException e) {}
            System.out.println("Mentor berhasil dihapus.");
        }
    }
}
