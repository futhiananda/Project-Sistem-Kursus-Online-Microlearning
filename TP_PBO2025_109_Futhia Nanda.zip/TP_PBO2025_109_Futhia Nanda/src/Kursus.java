import java.util.ArrayList;

public class Kursus {
    private String namaKursus;
    private Mentor mentor;
    private ArrayList<Modul> modulList = new ArrayList<>();

    public Kursus(String namaKursus, Mentor mentor) {
        this.namaKursus = namaKursus;
        this.mentor = mentor;
    }

    public void tambahModul(Modul m) {
        modulList.add(m);
    }

    public String getNamaKursus() {
        return namaKursus;
    }

    public Mentor getMentor() {
        return mentor;
    }

    public void setMentor(Mentor mentor) {
        this.mentor = mentor;
    }

    public ArrayList<Modul> getModulList() {
        return modulList;
    }
}
