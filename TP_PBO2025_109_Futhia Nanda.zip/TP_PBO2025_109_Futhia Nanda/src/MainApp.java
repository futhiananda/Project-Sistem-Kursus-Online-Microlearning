import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class MainApp {

    /* ================= LOAD MENTOR ================= */
    static void loadMentor(ArrayList<Mentor> daftarMentor) {
        try (BufferedReader br = new BufferedReader(new FileReader("mentor.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] d = line.split("\\|");
                daftarMentor.add(new Mentor(d[0], d[1]));
            }
        } catch (IOException e) {}
    }

    /* ================= LOAD PESERTA ================= */
    static void loadPeserta(ArrayList<Peserta> daftarPeserta) {
        try (BufferedReader br = new BufferedReader(new FileReader("peserta.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] d = line.split("\\|");
                daftarPeserta.add(new Peserta(d[0], d[1]));
            }
        } catch (IOException e) {}
    }

    /* ================= SIMPAN PROGRESS ================= */
    static void simpanSemuaProgress(ArrayList<Peserta> daftarPeserta) {
        try (FileWriter fw = new FileWriter("progress.txt")) {
            for (Peserta p : daftarPeserta) {
                for (KursusPeserta kp : p.getDaftarKursus()) {

                    String status = kp.getProgress() == 100
                            ? "SELESAI"
                            : "BELUM SELESAI";

                    fw.write(
                            p.getId() + "|" +
                                    p.getNama() + "|" +
                                    kp.getKursus().getNamaKursus() + "|" +
                                    kp.getProgress() + "|" +
                                    status + "\n"
                    );
                }
            }
        } catch (IOException e) {
            System.out.println("Gagal menyimpan progress.");
        }
    }


    /* ================= LOAD PROGRESS ================= */
    static void loadProgress(Peserta peserta,
                             ArrayList<Kursus> daftarKursus,
                             ArrayList<Mentor> daftarMentor) {

        peserta.getDaftarKursus().clear();

        try (BufferedReader br = new BufferedReader(new FileReader("progress.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] d = line.split("\\|");

                if (!d[0].equals(peserta.getId())) continue;

                Kursus k = null;
                Mentor m = null;

                for (Kursus ks : daftarKursus)
                    if (ks.getNamaKursus().equals(d[2])) k = ks;

                if (k != null) {
                    m = k.getMentor();
                    KursusPeserta kp = new KursusPeserta(k, m);
                    kp.setProgress(Integer.parseInt(d[3]));

                    // hitung modulIndex otomatis
                    int total = 0;
                    int index = 0;
                    for (Modul mod : k.getModulList()) {
                        if (total + mod.getBobot() <= kp.getProgress()) {
                            total += mod.getBobot();
                            index++;
                        }
                    }
                    kp.setModulIndex(index);

                    peserta.tambahKursus(kp);
                }
            }
        } catch (IOException e) {}
    }


    static Peserta cariPeserta(ArrayList<Peserta> daftarPeserta, String id) {
        for (Peserta p : daftarPeserta)
            if (p.getId().equalsIgnoreCase(id)) return p;
        return null;
    }

    /* ================= MAIN ================= */
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        ArrayList<Peserta> daftarPeserta = new ArrayList<>();
        ArrayList<Mentor> daftarMentor = new ArrayList<>();
        ArrayList<Kursus> daftarKursus = new ArrayList<>();

        loadMentor(daftarMentor);
        loadPeserta(daftarPeserta);

        // ===== MENTOR DEFAULT (AGAR TIDAK KOSONG) =====
        if (daftarMentor.isEmpty()) {
            daftarMentor.add(new Mentor("M01", "Dr. Arba'az Narundi"));
            daftarMentor.add(new Mentor("M02", "Ir. Zardhik Gasendra"));
            daftarMentor.add(new Mentor("M03", "Ardyysa Putri, S.Kom., M.Cs."));
            daftarMentor.add(new Mentor("M04", "Alfarka Hasbiyuda, S.Kom"));
            daftarMentor.add(new Mentor("M05", "Alsyifa Sri Aulia, M.T"));

            try (FileWriter fw = new FileWriter("mentor.txt")) {
                fw.write("M01|Dr. Arba'az Narundi1\n");
                fw.write("M02|Ir. Zardhik Gasendra\n");
                fw.write("M03|Ardyysa Putri, S.Kom., M.Cs.\n");
                fw.write("M04|Alfarka Hasbiyuda, S.Kom\n");
                fw.write("M05|Alsyifa Sri Aulia, M.T\n");
            } catch (IOException e) {}
        }


        // ===== KURSUS + MENTOR =====
        Kursus web = new Kursus("Web Development", daftarMentor.get(0));
        web.tambahModul(new Modul("HTML & CSS", 30));
        web.tambahModul(new Modul("JavaScript Dasar", 30));
        web.tambahModul(new Modul("Backend Java", 40));

        Kursus data = new Kursus("Data Science Dasar", daftarMentor.get(1));
        data.tambahModul(new Modul("Pengantar Data", 25));
        data.tambahModul(new Modul("Python untuk Data", 35));
        data.tambahModul(new Modul("Machine Learning Dasar", 40));

        Kursus mobile = new Kursus("Mobile App Development", daftarMentor.get(2));
        mobile.tambahModul(new Modul("UI/UX Mobile", 30));
        mobile.tambahModul(new Modul("Android Dasar", 30));
        mobile.tambahModul(new Modul("Firebase", 40));

        Kursus uiux = new Kursus("UI/UX Design", daftarMentor.get(3));
        uiux.tambahModul(new Modul("Design Thinking", 30));
        uiux.tambahModul(new Modul("Figma Dasar", 30));
        uiux.tambahModul(new Modul("Prototype & Testing", 40));

        Kursus cyber = new Kursus("Cyber Security Dasar", daftarMentor.get(4));
        cyber.tambahModul(new Modul("Keamanan Sistem", 30));
        cyber.tambahModul(new Modul("Jaringan Dasar", 30));
        cyber.tambahModul(new Modul("Ethical Hacking Dasar", 40));

        daftarKursus.add(web);
        daftarKursus.add(data);
        daftarKursus.add(mobile);
        daftarKursus.add(uiux);
        daftarKursus.add(cyber);


        Admin admin = new Admin("admin", "Administrator");

        int pilih;
        do {
            System.out.println("\n========================================");
            System.out.println("             SELAMAT DATANG DI           ");
            System.out.println("    SISTEM KURSUS ONLINE MICROLEARNING  ");
            System.out.println("========================================");
            System.out.println("              MENU LOGIN               ");
            System.out.println("========================================");
            System.out.println("1. Admin");
            System.out.println("2. Login Peserta");
            System.out.println("3. Daftar Peserta");
            System.out.println("0. Keluar");
            System.out.print("Pilih: ");
            pilih = input.nextInt();

            switch (pilih) {

                case 1 -> {
                    input.nextLine();
                    System.out.print("Username Admin: ");
                    String u = input.nextLine();
                    System.out.print("Password Admin: ");
                    String p = input.nextLine();

                    if (u.equals("admin") && p.equals("admin01")) {
                        menuAdmin(admin, daftarMentor, daftarKursus, input);
                    } else {
                        System.out.println("Login admin gagal!");
                    }
                }

                case 2 -> {
                    System.out.print("Masukkan ID Peserta: ");
                    String id = input.next();

                    Peserta ps = cariPeserta(daftarPeserta, id);
                    if (ps != null) {
                        loadProgress(ps, daftarKursus, daftarMentor);
                        menuPeserta(ps, daftarKursus, daftarMentor, daftarPeserta, input);
                    } else {
                        System.out.println("Peserta tidak ditemukan.");
                    }
                }

                case 3 -> {
                    System.out.print("ID Peserta: ");
                    String id = input.next();
                    input.nextLine();
                    System.out.print("Nama Peserta: ");
                    String nama = input.nextLine();

                    daftarPeserta.add(new Peserta(id, nama));
                    try (FileWriter fw = new FileWriter("peserta.txt", true)) {
                        fw.write(id + "|" + nama + "\n");
                    } catch (IOException e) {}
                    System.out.println("Pendaftaran berhasil!");
                }
            }

        } while (pilih != 0);

        input.close();
        System.out.println("Program selesai.");
    }

    /* ================= MENU ADMIN ================= */
    static void menuAdmin(
            Admin admin,
            ArrayList<Mentor> daftarMentor,
            ArrayList<Kursus> daftarKursus,
            Scanner input)
    {
        int p;
        do {
            System.out.println("\n=== MENU ADMIN ===");
            System.out.println("1. Tambah Mentor");
            System.out.println("2. Lihat Mentor");
            System.out.println("3. Hapus Mentor");
            System.out.println("0. Kembali");
            System.out.print("Pilih: ");
            p = input.nextInt();
            input.nextLine();

            switch (p) {
                case 1 -> {
                    System.out.print("ID Mentor  : ");
                    String id = input.nextLine();
                    System.out.print("Nama Mentor: ");
                    String nama = input.nextLine();

                    Mentor mentorBaru = new Mentor(id, nama);
                    admin.tambahMentor(daftarMentor, mentorBaru);

                    // ===== PILIH KURSUS =====
                    System.out.println("\nPilih kursus yang akan diajar:");
                    for (int i = 0; i < daftarKursus.size(); i++) {
                        System.out.println((i + 1) + ". " +
                                daftarKursus.get(i).getNamaKursus() +
                                " (Mentor saat ini: " +
                                daftarKursus.get(i).getMentor().getNama() + ")");
                    }

                    System.out.print("Pilih: ");
                    int pilihKursus = input.nextInt();
                    input.nextLine();

                    Kursus k = daftarKursus.get(pilihKursus - 1);
                    k.setMentor(mentorBaru);

                    System.out.println("Mentor berhasil ditetapkan ke kursus " +
                            k.getNamaKursus());
                }

                case 2 -> {
                    for (int i = 0; i < daftarMentor.size(); i++)
                        System.out.println((i + 1) + ". " + daftarMentor.get(i).getNama());
                }
                case 3 -> {
                    for (int i = 0; i < daftarMentor.size(); i++)
                        System.out.println((i + 1) + ". " + daftarMentor.get(i).getNama());
                    admin.hapusMentor(daftarMentor, input.nextInt() - 1);
                }
            }
        } while (p != 0);
    }

    /* ================= MENU PESERTA ================= */
    static void menuPeserta(
            Peserta peserta,
            ArrayList<Kursus> daftarKursus,
            ArrayList<Mentor> daftarMentor,
            ArrayList<Peserta> daftarPeserta,
            Scanner input) {

        int p;
        do {
            System.out.println("\n=== MENU PESERTA ===");
            System.out.println("1. Ambil Kursus");
            System.out.println("2. Lihat Progress");
            System.out.println("3. Lanjut Belajar");
            System.out.println("0. Kembali");
            System.out.print("Pilih: ");
            p = input.nextInt();

            switch (p) {
                case 1 -> {
                    for (int i = 0; i < daftarKursus.size(); i++) {
                        Kursus k = daftarKursus.get(i);
                        System.out.println((i + 1) + ". " + k.getNamaKursus()
                                + " | Mentor: " + k.getMentor().getNama());
                    }
                    System.out.print("Pilih kursus : ");
                    int i = input.nextInt();
                    peserta.tambahKursus(
                            new KursusPeserta(daftarKursus.get(i - 1),
                                    daftarKursus.get(i - 1).getMentor()));
                    simpanSemuaProgress(daftarPeserta);
                }

                case 2 -> {
                    loadProgress(peserta, daftarKursus, daftarMentor);

                    System.out.println("\n==========================================");
                    System.out.println("           PROGRESS BELAJAR PESERTA        ");
                    System.out.println("==========================================");
                    System.out.println("ID   : " + peserta.getId());
                    System.out.println("Nama : " + peserta.getNama());
                    System.out.println("------------------------------------------");

                    if (peserta.getDaftarKursus().isEmpty()) {
                        System.out.println("Belum mengambil kursus.");
                    } else {
                        for (KursusPeserta kp : peserta.getDaftarKursus()) {
                            String status = kp.getProgress() == 100
                                    ? "SELESAI"
                                    : "BELUM SELESAI";

                            System.out.println("Kursus   : " + kp.getKursus().getNamaKursus());
                            System.out.println("Mentor   : " + kp.getMentor().getNama());
                            System.out.println("Progress : " + kp.getProgress() + "%");
                            System.out.println("Status   : " + status);
                            System.out.println("------------------------------------------");
                        }
                    }
                }


                case 3 -> {
                    if (peserta.getDaftarKursus().isEmpty()) break;
                    for (int i = 0; i < peserta.getDaftarKursus().size(); i++)
                        System.out.println((i + 1) + ". " +
                                peserta.getDaftarKursus().get(i)
                                        .getKursus().getNamaKursus());
                    System.out.print("Pilih Progress yang ingin di lanjutkan : ");
                    int i = input.nextInt();
                    peserta.getDaftarKursus().get(i - 1).belajarModul();
                    simpanSemuaProgress(daftarPeserta);
                }
            }
        } while (p != 0);
    }
}
