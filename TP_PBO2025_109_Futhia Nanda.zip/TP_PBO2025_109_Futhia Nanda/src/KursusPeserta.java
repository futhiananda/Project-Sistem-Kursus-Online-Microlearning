public class KursusPeserta {
    private Kursus kursus;
    private Mentor mentor;
    private int progress;
    private int modulIndex;

    public KursusPeserta(Kursus kursus, Mentor mentor) {
        this.kursus = kursus;
        this.mentor = mentor;
        this.progress = 0;
        this.modulIndex = 0;
    }

    public void belajarModul() {
        if (modulIndex < kursus.getModulList().size()) {
            progress += kursus.getModulList().get(modulIndex).getBobot();
            modulIndex++;
            if (progress > 100) progress = 100;
            System.out.println("Belajar modul: " +
                    kursus.getModulList().get(modulIndex - 1).getNama());
        } else {
            System.out.println("Semua modul sudah selesai.");
        }
    }

    public Kursus getKursus() {
        return kursus;
    }

    public Mentor getMentor() {
        return mentor;
    }

    public int getProgress() {
        return progress;
    }

    public int getModulIndex() {
        return modulIndex;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }

    public void setModulIndex(int modulIndex) {
        this.modulIndex = modulIndex;
    }
}
