public class KursusPeserta {
    private Kursus kursus;
    private int progress = 0;
    private String[] modul = {"Pengantar","Dasar","Menengah","Lanjutan"};

    public KursusPeserta(Kursus k){ kursus=k; }

    public void belajar(){
        if(progress<100) progress+=25;
    }

    public int getProgress(){ return progress; }
    public Kursus getKursus(){ return kursus; }
    public String getModul(){ return modul[progress/25 - 1]; }
}
