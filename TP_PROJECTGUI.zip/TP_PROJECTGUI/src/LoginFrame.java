import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {

    public LoginFrame() {
        setTitle("Microlearning App");
        setSize(450,400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(10,10));
        root.setBorder(BorderFactory.createEmptyBorder(30,30,30,30));

        JLabel title = new JLabel("<html><center>SISTEM KURSUS ONLINE MICROLEARNING</center></html>");
        title.setFont(new Font("Times New Roman", Font.BOLD, 18));
        title.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel menu = new JPanel(new GridLayout(4,1,12,12));

        JButton admin = new JButton("Login Admin");
        JButton login = new JButton("Login Peserta");
        JButton daftar = new JButton("Daftar Peserta");
        JButton keluar = new JButton("Keluar");

        UIStyle.button(admin);
        UIStyle.button(login);
        UIStyle.button(daftar);
        UIStyle.button(keluar);

        menu.add(admin);
        menu.add(login);
        menu.add(daftar);
        menu.add(keluar);

        root.add(title, BorderLayout.NORTH);
        root.add(menu, BorderLayout.CENTER);
        add(root);

        admin.addActionListener(e -> loginAdmin());
        login.addActionListener(e -> loginPeserta());
        daftar.addActionListener(e -> daftarPeserta());
        keluar.addActionListener(e -> System.exit(0));

        setVisible(true);
    }

    private void loginAdmin() {
        JTextField u = new JTextField();
        JPasswordField p = new JPasswordField();
        Object[] f = {"Username:", u, "Password:", p};

        if (JOptionPane.showConfirmDialog(this,f,"Login Admin",JOptionPane.OK_CANCEL_OPTION)
                == JOptionPane.OK_OPTION) {

            if (u.getText().equals("admin") &&
                    String.valueOf(p.getPassword()).equals("admin01")) {

                new AdminFrame(new Admin("A01","Admin"), MainApp.daftarMentor);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this,"Login gagal!");
            }
        }
    }

    private void daftarPeserta() {
        JTextField id = new JTextField();
        JTextField nama = new JTextField();
        Object[] f = {"ID Peserta:", id, "Nama Peserta:", nama};

        if (JOptionPane.showConfirmDialog(this,f,"Daftar Peserta",JOptionPane.OK_CANCEL_OPTION)
                == JOptionPane.OK_OPTION) {

            MainApp.daftarPeserta.add(new Peserta(id.getText(), nama.getText()));
            JOptionPane.showMessageDialog(this,"Pendaftaran berhasil!");
        }
    }

    private void loginPeserta() {
        String id = JOptionPane.showInputDialog("Masukkan ID Peserta:");
        for (Peserta p : MainApp.daftarPeserta) {
            if (p.getId().equals(id)) {
                new PesertaFrame(p, MainApp.daftarKursus);
                dispose();
                return;
            }
        }
        JOptionPane.showMessageDialog(this,"Peserta belum terdaftar!");
    }
}
