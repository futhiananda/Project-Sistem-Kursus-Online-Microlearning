public class Mentor {
    private String id,nama;
    public Mentor(String id,String nama){
        this.id=id; this.nama=nama;
    }
    public String getNama(){ return nama; }
}
