import javax.swing.*;
import java.util.ArrayList;

public class MainApp {

    public static ArrayList<Mentor> daftarMentor = new ArrayList<>();
    public static ArrayList<Kursus> daftarKursus = new ArrayList<>();
    public static ArrayList<Peserta> daftarPeserta = new ArrayList<>();

    public static void main(String[] args) {

        // ===== Nimbus Look & Feel (modern built-in) =====
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // ===== DATA SESUAI CONSOLE =====
        daftarMentor.add(new Mentor("M01","Dr. Arba'az Narundi1"));
        daftarMentor.add(new Mentor("M02","Ir. Zardhik Gasendra"));
        daftarMentor.add(new Mentor("M03","Ardyysa Putri, S.Kom., M.Cs."));
        daftarMentor.add(new Mentor("M04","Alfarka Hasbiyuda, S.Kom"));
        daftarMentor.add(new Mentor("M05","Alsyifa Sri Aulia, M.T"));
        daftarMentor.add(new Mentor("M06","Arjuna Areksa, S.T"));

        daftarKursus.add(new Kursus("Web Development", daftarMentor.get(0)));
        daftarKursus.add(new Kursus("Data Science Dasar", daftarMentor.get(1)));
        daftarKursus.add(new Kursus("Mobile App Development", daftarMentor.get(2)));
        daftarKursus.add(new Kursus("UI/UX Design", daftarMentor.get(3)));
        daftarKursus.add(new Kursus("Cyber Security Dasar", daftarMentor.get(4)));

        new LoginFrame();
    }
}
