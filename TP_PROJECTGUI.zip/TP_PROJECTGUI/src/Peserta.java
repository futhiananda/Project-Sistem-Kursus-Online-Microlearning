import java.util.ArrayList;

public class Peserta {
    private String id,nama;
    private ArrayList<KursusPeserta> daftarKursus = new ArrayList<>();

    public Peserta(String id,String nama){
        this.id=id; this.nama=nama;
    }

    public void tambahKursus(KursusPeserta k){ daftarKursus.add(k); }
    public ArrayList<KursusPeserta> getDaftarKursus(){ return daftarKursus; }
    public String getId(){ return id; }
    public String getNama(){ return nama; }
}
