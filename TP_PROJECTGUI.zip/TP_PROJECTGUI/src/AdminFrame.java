import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class AdminFrame extends JFrame {

    private Admin admin;
    private ArrayList<Mentor> mentor;

    public AdminFrame(Admin a, ArrayList<Mentor> m) {
        admin = a;
        mentor = m;

        setTitle("Dashboard Admin");
        setSize(420,350);
        setLocationRelativeTo(null);

        JPanel p = new JPanel(new GridLayout(4,1,12,12));
        p.setBorder(BorderFactory.createEmptyBorder(25,25,25,25));

        JButton t = new JButton("Tambah Mentor");
        JButton l = new JButton("Lihat Mentor");
        JButton h = new JButton("Hapus Mentor");
        JButton k = new JButton("Kembali");

        UIStyle.button(t);
        UIStyle.button(l);
        UIStyle.button(h);
        UIStyle.button(k);

        p.add(t); p.add(l); p.add(h); p.add(k);
        add(p);

        t.addActionListener(e -> tambah());
        l.addActionListener(e -> lihat());
        h.addActionListener(e -> hapus());
        k.addActionListener(e -> { new LoginFrame(); dispose(); });

        setVisible(true);
    }

    private void tambah() {
        JTextField id = new JTextField();
        JTextField nama = new JTextField();
        Object[] f = {"ID:", id, "Nama:", nama};

        if (JOptionPane.showConfirmDialog(this,f,"Tambah Mentor",JOptionPane.OK_CANCEL_OPTION)
                == JOptionPane.OK_OPTION) {

            admin.tambahMentor(mentor,new Mentor(id.getText(), nama.getText()));
            JOptionPane.showMessageDialog(this,"Mentor berhasil ditambahkan");
        }
    }

    private void lihat() {
        StringBuilder sb = new StringBuilder();
        for (int i=0;i<mentor.size();i++)
            sb.append(i+1).append(". ").append(mentor.get(i).getNama()).append("\n");

        JOptionPane.showMessageDialog(this,sb.toString(),"Daftar Mentor",JOptionPane.INFORMATION_MESSAGE);
    }

    private void hapus() {
        String idx = JOptionPane.showInputDialog("Index mentor:");
        admin.hapusMentor(mentor,Integer.parseInt(idx)-1);
        JOptionPane.showMessageDialog(this,"Mentor berhasil dihapus");
    }
}
