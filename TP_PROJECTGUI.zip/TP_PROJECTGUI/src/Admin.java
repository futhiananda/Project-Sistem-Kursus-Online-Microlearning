import java.util.ArrayList;

public class Admin {
    private String id,nama;
    public Admin(String id,String nama){
        this.id=id; this.nama=nama;
    }
    public void tambahMentor(ArrayList<Mentor> l,Mentor m){ l.add(m);}
    public void hapusMentor(ArrayList<Mentor> l,int i){
        if(i>=0 && i<l.size()) l.remove(i);
    }
}
