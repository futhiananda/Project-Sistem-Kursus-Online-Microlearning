import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class PesertaFrame extends JFrame {

    private Peserta peserta;
    private ArrayList<Kursus> kursus;

    public PesertaFrame(Peserta p, ArrayList<Kursus> k) {
        peserta = p;
        kursus = k;

        setTitle("Dashboard Peserta");
        setSize(450,380);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10,10));
        root.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));

        JLabel info = new JLabel("Login sebagai: "+peserta.getNama());
        info.setFont(UIStyle.normal());

        JPanel menu = new JPanel(new GridLayout(4,1,12,12));

        JButton a = new JButton("Ambil Kursus");
        JButton pgr = new JButton("Lihat Progress");
        JButton b = new JButton("Lanjut Belajar");
        JButton kbl = new JButton("Kembali");

        UIStyle.button(a);
        UIStyle.button(pgr);
        UIStyle.button(b);
        UIStyle.button(kbl);

        menu.add(a); menu.add(pgr); menu.add(b); menu.add(kbl);

        root.add(info,BorderLayout.NORTH);
        root.add(menu,BorderLayout.CENTER);
        add(root);

        a.addActionListener(e -> ambil());
        pgr.addActionListener(e -> progress());
        b.addActionListener(e -> belajar());
        kbl.addActionListener(e -> { new LoginFrame(); dispose(); });

        setVisible(true);
    }

    private void ambil() {
        String[] list = kursus.stream()
                .map(k -> k.getNamaKursus()+" | Mentor: "+k.getMentor().getNama())
                .toArray(String[]::new);

        String pilih = (String) JOptionPane.showInputDialog(
                this,"Pilih Kursus","Ambil Kursus",
                JOptionPane.PLAIN_MESSAGE,null,list,list[0]);

        for (Kursus k : kursus)
            if (pilih.startsWith(k.getNamaKursus()))
                peserta.tambahKursus(new KursusPeserta(k));
    }

    private void progress() {
        StringBuilder sb = new StringBuilder();
        sb.append("ID   : ").append(peserta.getId()).append("\n");
        sb.append("Nama : ").append(peserta.getNama()).append("\n\n");

        for (KursusPeserta kp : peserta.getDaftarKursus()) {
            sb.append("Kursus   : ").append(kp.getKursus().getNamaKursus()).append("\n");
            sb.append("Mentor   : ").append(kp.getKursus().getMentor().getNama()).append("\n");
            sb.append("Progress : ").append(kp.getProgress()).append("%\n");
            sb.append("Status   : ").append(kp.getProgress()==100?"SELESAI":"BELUM SELESAI").append("\n------------------\n");
        }
        JOptionPane.showMessageDialog(this,sb.toString(),"Progress Belajar",JOptionPane.INFORMATION_MESSAGE);
    }

    private void belajar() {
        if (peserta.getDaftarKursus().isEmpty()) return;

        String[] list = peserta.getDaftarKursus().stream()
                .map(kp -> kp.getKursus().getNamaKursus())
                .toArray(String[]::new);

        String pilih = (String) JOptionPane.showInputDialog(
                this,"Pilih Kursus","Lanjut Belajar",
                JOptionPane.PLAIN_MESSAGE,null,list,list[0]);

        for (KursusPeserta kp : peserta.getDaftarKursus())
            if (kp.getKursus().getNamaKursus().equals(pilih)) {
                kp.belajar();
                JOptionPane.showMessageDialog(this,"Belajar modul: "+kp.getModul());
            }
    }
}
