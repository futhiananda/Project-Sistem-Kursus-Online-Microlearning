import javax.swing.*;
import java.awt.*;

public class UIStyle {

    public static Font title() {
        return new Font("Times New Roman", Font.BOLD, 20);
    }

    public static Font normal() {
        return new Font("Times New Roman", Font.PLAIN, 14);
    }

    public static void button(JButton b) {
        b.setFont(normal());
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
}
