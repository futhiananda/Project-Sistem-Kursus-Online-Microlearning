public class Kursus {
    private String namaKursus;
    private Mentor mentor;
    public Kursus(String n,Mentor m){
        namaKursus=n; mentor=m;
    }
    public String getNamaKursus(){ return namaKursus; }
    public Mentor getMentor(){ return mentor; }
}
